# دفتر الأجوبة — نسخة APK

هاد المشروع فيه التطبيق الحالي وWorkflow ديال GitHub Actions كيصاوب APK أوتوماتيكياً.

## من الهاتف فقط
1. فك الضغط على ZIP.
2. دخل لـ GitHub من المتصفح وأنشئ Repository جديد.
3. ارفع **جميع الملفات والمجلدات** ديال المشروع، بما فيها `.github/workflows/build-apk.yml`.
4. من GitHub افتح **Actions** ثم workflow اسمه **Build APK**.
5. ضغط **Run workflow**.
6. منين يكمل البناء، دخل للـworkflow الناجح، ثم **Artifacts** وحمّل `daftar-alajwiba-apk`.
7. فك ZIP ديال Artifact وخذ `app-debug.apk` وثبّتو فالهاتف.

إلى كان GitHub كيسول على تفعيل Actions، فعّلها من Settings > Actions.
